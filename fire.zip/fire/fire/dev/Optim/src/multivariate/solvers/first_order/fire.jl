#
#  Fire
#
# {Tf, T, Tprep<:Union{Function, Nothing}, IL, L}
struct Fire <: FirstOrderOptimizer
    delaystep
    dtgrow
    dtshrink
    alphazero
    alphashrink
    dtmax
    manifold::Manifold
end

Base.summary(::Fire) = "Fast Inertial Relaxation Engine"

"""
# Fire: Fast Inertial Relaxation Engine
## Constructor
```julia
ConjugateGradient(; alphaguess = LineSearches.InitialHagerZhang(),
linesearch = LineSearches.HagerZhang(),
eta = 0.4,
P = nothing,
precondprep = (P, x) -> nothing,
manifold = Flat())
```
The strictly positive constant ``eta`` is used in determining
the next step direction, and the default here deviates from the one used in the
original paper (where it was ``0.01``). See more details in the original papers
referenced below.

## Description
The `ConjugateGradient` method implements Hager and Zhang (2006) and elements
from Hager and Zhang (2013). Notice, the default `linesearch` is `HagerZhang`
from LineSearches.jl. This line search is exactly the one proposed in Hager and
Zhang (2006).

## References
 - W. W. Hager and H. Zhang (2006) Algorithm 851: CG_DESCENT, a conjugate gradient method with guaranteed descent. ACM Transactions on Mathematical Software 32: 113-137.
 - W. W. Hager and H. Zhang (2013), The Limited Memory Conjugate Gradient Method. SIAM Journal on Optimization, 23, pp. 2150-2168.
"""
function Fire(; delaystep = 20,    # Number of steps to wait after P < 0 before increasing ∆t
                dtgrow = 1.1,      # Factor by which ∆t is increased
                dtshrink = 0.5,    # Factor by which ∆t is decreased
                alphazero = 0.1,   # Coefficient for mixing velocity and force vectors
                alphashrink = 0.99,# Factor by which α is decreased
                dtmax = 10.0,        # The maximum timestep is tmax × ∆t start
                #tmin = 0.02,       # The minimum timestep is tmin × ∆t start
                manifold::Manifold=Flat())

     Fire(delaystep, dtgrow, dtshrink, alphazero, alphashrink, dtmax,
          manifold)
end

# {Tx,T,G}
mutable struct FireState <: AbstractOptimizerState
    x #::Tx
    x_previous
    velocity #::Tx
    g_previous#::G
    f_x_previous#::T
    dt #::Real
    nsteps_positive #::Int
    alpha #::Real
end

function initial_state(method::Fire, options, d, initial_x)
    T = eltype(initial_x)
    initial_x = copy(initial_x)

    #retract!(method.manifold, initial_x)

    value_gradient!(d, initial_x) # Initialize x(t) and F(x(t))

    #project_tangent!(method.manifold, gradient(d), initial_x)
    #pg = copy(gradient(d))

    FireState(initial_x, # Maintain current state in state.x
              copy(initial_x),
              zeros(T, size(initial_x)), # velocity
              similar(initial_x), # Inte
              real(T)(NaN),     # Store previous f in state.f_x_previous
              method.dtmax/100.0,          # dt init
              0,                         # nsteps_positive init
              method.alphazero)
end


function update_state!(d, state::FireState, method::Fire)

    # Maintain a record of previous position
    copyto!(state.x_previous, state.x)
    state.f_x_previous  = value(d)
    #copyto!(state.g_previous, gradient(d))

    velocity = state.velocity
    force = -gradient(d)
    P = sum(force .* velocity)

    if P > 0
        println("P+ ", state.dt, state.velocity, " f", value(d))
        state.nsteps_positive += 1
        #nsteps_negative = 0

        v2 = sum( velocity .* velocity )
        f2 = sum( force .* force )

        scale1 = 1 - state.alpha
        if f2 < 1e-20
            scale2 = 0.0
        else
            scale2 = state.alpha * sqrt(v2/f2)
        end

        if state.nsteps_positive > method.delaystep
            state.dt = min(state.dt * method.dtgrow, method.dtmax)
            state.alpha *= method.alphashrink
            println("grow dt ->", state.dt)
        end
        # ...why after defining scale1 and 2?

    else
        println("P-  dt:", state.dt, "  f:", value(d))
        state.nsteps_positive = 0
        # nsteps_negative += 1
        # break if  nsteps_negative > nsteps_negative_max

        # Stop & Correct the uphill motion
        @. state.x -= 0.5 * state.dt * velocity
        fill!(velocity,  0.0)

        #delayflag = 1
        #if ntimestep - ntimestep_start < delaystep && delaystep_start_flag
        #    delayflag = 0
        #end
        #if delayflag
        state.alpha = method.alphazero
        #if state.dt * method.dtshrink >= dtmin
        state.dt *= method.dtshrink
        println("shrink dt:", state.dt)
        #end
        #end

        # stopping criterion while stuck in a local bassin of the PES

        #vdotf_negatif++;
        #if (max_vdotf_negatif > 0 && vdotf_negatif > max_vdotf_negatif)
        #return MAXVDOTF;

    end

    # // limit timestep so no particle moves further than dmax
    #
    # dtvone = dt;
    #
    # for (int i = 0; i < nlocal; i++) {
    # vmax = MAX(fabs(v[i][0]),fabs(v[i][1]));
    # vmax = MAX(vmax,fabs(v[i][2]));
    # if (dtvone*vmax > dmax) dtvone = dmax/vmax;
    # }

    # -- Semi-implicit Euler integration --

    @. velocity += state.dt * force;
    if P > 0.0
        @. velocity = scale1*velocity + scale2*force
    end
    @. state.x += state.dt * velocity

    print("dt:", state.dt, "  alpha:", state.alpha)
    println("v: ", state.velocity )
    println("x: ", state.x , " previous:", state.x_previous)

    # Update forces
    value_gradient!!(d, state.x)
    #force .= -gradient(d)
    #state.f_x_previous = value(d)
    #neval++;
    # lssuccess == false # break on linesearch error
end

update_g!(d, state, method::Fire) = nothing

function trace!(tr, d, state, iteration, method::Fire, options, curr_time=time())
  common_trace!(tr, d, state, iteration, method, options, curr_time)
end
