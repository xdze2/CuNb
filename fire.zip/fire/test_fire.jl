# #using Plots
# atreplinit() do repl
#     try
#         @eval using Revise
#         @async Revise.wait_steal_repl_backend()
#     catch e
#         @warn(e.msg)
#     end
# end

import Optim
println("hello")

function f(x)
    return (1.0 - x[1])^2 + 100.0 * (x[2] - x[1]^2)^2
end

function g!(G, x)
    G[1] = -2.0 * (1.0 - x[1]) - 400.0 * (x[2] - x[1]^2) * x[1]
    G[2] = 200.0 * (x[2] - x[1]^2)
end

# Quadratic:
function f(x)
    return (1.0 - x[1])^2 + (1.0 - x[2])^2
end

function g!(G, x)
    G[1] = -2.0 * (1.0 - x[1])
    G[2] = -2.0 * (1.0 - x[2])
end


initial_x = zeros(2)

#plot()
#yaxis!("value", :log10)

# Fire
res = Optim.optimize(f, g!, initial_x, Optim.Fire(dtmax = 80.0, delaystep=2),
                        Optim.Options(store_trace = true,
                                      show_trace = false,
                                      extended_trace = true,
                                      allow_f_increases = true,
                                      iterations = 50))


#n = map(x->x.value, Optim.trace(res))
#plot!(n_GD, label="Fire")
#
# # GradientDescent
# res_GD = Optim.optimize(f, g!, initial_x, Optim.GradientDescent(),
#                         Optim.Options(store_trace = true,
#                                       show_trace = false))
# n_GD = map(x->x.value, Optim.trace(res_GD))
# plot!(n_GD, label="Gradient Descent")
#
# # BFGS
res_BFGS = Optim.optimize(f, g!, initial_x,
                          Optim.BFGS(),
                          Optim.Options(store_trace = true,
                                        show_trace = false))
# n_BFGS = map(x->x.value, Optim.trace(res_BFGS))
# plot!(n_BFGS, label="BFGS")
#
#
# # ConjugateGradient
res = Optim.optimize(f, g!, initial_x, Optim.ConjugateGradient(),
                         Optim.Options( store_trace = true,
                                        show_trace = false))
# n = map(x->x.value, Optim.trace(res))
# plot!(n, label="Conjugate Gradient")
