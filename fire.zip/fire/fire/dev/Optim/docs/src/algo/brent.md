# Brent's Method
## Constructor

## Description
## Example
## References
R. P. Brent (2002) Algorithms for Minimization Without Derivatives. Dover edition.
