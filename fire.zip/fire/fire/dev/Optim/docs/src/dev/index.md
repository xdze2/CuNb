### Using Nelder Mead
