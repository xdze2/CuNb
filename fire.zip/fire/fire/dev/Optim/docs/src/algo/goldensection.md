# Golden Section
## Constructor
## Description
## Example
## References
